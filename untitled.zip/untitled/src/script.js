// Function to generate "Problema" based on inputs
function generateProblema() {
  const pregunta = document.getElementById('pregunta').value;
  const vi = document.getElementById('vi').value;
  const objetivo = document.getElementById('objetivo').value;
  const lugar = document.getElementById('lugar').value;

  const problema = `¿${pregunta} ${vi} ${objetivo} ${lugar}?`;
  document.getElementById('problema-output').innerText = problema;
}

// Function to generate "Objetivos" based on inputs
function generateObjetivo() {
  const objetivo = document.getElementById('objetivo').value;
  const vd = document.getElementById('vd').value;
  const vi = document.getElementById('vi').value;
  const lugar = document.getElementById('lugar').value;
  const tiempo = document.getElementById('tiempo').value;

  const objetivoGeneral = `${objetivo} ${vd} ${vi} ${lugar} ${tiempo}`;
  document.getElementById('objetivo-output').innerText = objetivoGeneral;
}

// Function to generate "Hipótesis" based on inputs
function generateHipotesis() {
  const hipotesis = document.getElementById('hipotesis').value;
  const vi = document.getElementById('vi').value;
  const objetivo = document.getElementById('objetivo').value;
  const vd = document.getElementById('vd').value;
  const lugar = document.getElementById('lugar').value;
  const tiempo = document.getElementById('tiempo').value;

  const hypothesisStatement = `Si ${hipotesis} ${vi}, entonces ${objetivo} ${vd} ${lugar} ${tiempo}`;
  document.getElementById('hipotesis-output').innerText = hypothesisStatement;
}
